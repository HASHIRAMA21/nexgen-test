package com.example.nextgenapi.entities;

public enum Status {
    BLANK, PENDING, FINISHED
}
