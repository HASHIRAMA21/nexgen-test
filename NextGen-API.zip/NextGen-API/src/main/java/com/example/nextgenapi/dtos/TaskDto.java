package com.example.nextgenapi.dtos;

import com.example.nextgenapi.entities.Status;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Builder;
import lombok.Data;

import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;

@Data
@Builder
public class TaskDto {
    private UUID id;
    private String title;
    private String description;
    private Status status;
    //private Timestamp createdAt;
    //private Timestamp finishedAt;
}