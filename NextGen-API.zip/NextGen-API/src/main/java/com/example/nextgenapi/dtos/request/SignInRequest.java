package com.example.nextgenapi.dtos.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor @NoArgsConstructor @ToString
public class SignInRequest {

    @NotBlank
    private String username;

    @NotBlank
    private String email;
    @NotBlank
    private String password;

}