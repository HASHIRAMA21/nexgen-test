package com.example.nextgenapi.repositories;

import com.example.nextgenapi.entities.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@RepositoryRestResource
public interface TaskRepository extends JpaRepository<Task, UUID> {

}
