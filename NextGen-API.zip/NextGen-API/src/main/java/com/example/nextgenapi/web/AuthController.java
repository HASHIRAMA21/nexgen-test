package com.example.nextgenapi.web;

import com.example.nextgenapi.configs.JwtUtils;
import com.example.nextgenapi.dtos.request.SignInRequest;
import com.example.nextgenapi.dtos.request.SignUpRequest;
import com.example.nextgenapi.dtos.response.MessageResponse;
import com.example.nextgenapi.dtos.response.SignInResponse;
import com.example.nextgenapi.entities.ERole;
import com.example.nextgenapi.entities.Role;
import com.example.nextgenapi.entities.User;
import com.example.nextgenapi.repositories.RoleRepository;
import com.example.nextgenapi.repositories.UserRepository;
import com.example.nextgenapi.services.UserDetailsServiceImpl;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static com.example.nextgenapi.entities.ERole.ROLE_ADMIN;
import static com.example.nextgenapi.entities.ERole.ROLE_MODERATOR;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/auth/")
@ExternalDocumentation
public class AuthController {
    AuthenticationManager authenticationManager;

    UserRepository userRepository;

    RoleRepository roleRepository;

    PasswordEncoder encoder;

    JwtUtils jwtUtils;

    public AuthController(AuthenticationManager authenticationManager, UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder encoder, JwtUtils jwtUtils) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.encoder = encoder;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/sigin")

    public ResponseEntity<?> singIn(@Valid @RequestBody SignInRequest signInRequest) {
        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(signInRequest.getUsername(), signInRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);

        UserDetailsServiceImpl userDetailsService = (UserDetailsServiceImpl) authentication.getPrincipal();
        ResponseCookie responseCookie = jwtUtils.generateJwtCookie(userDetailsService);

        List<String> roles = userDetailsService.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();


        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, responseCookie.toString())
                .body(new SignInResponse(userDetailsService.getUsername(),
                        userDetailsService.getEmail(),
                        roles
                ));


    }

    public ResponseEntity<?> singUp(@Valid @RequestBody SignUpRequest signUpRequest) {
        if(userRepository.existsByUsername(signUpRequest.getUsername())){
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Username is already taked"));
        }
        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Email is already in use!"));
        }
        User user;

        user = new User(UUID.randomUUID(),signUpRequest.getFirstName(),
                signUpRequest.getLastName(),
                signUpRequest.getUsername(),
                signUpRequest.getEmail(),
                encoder.encode(signUpRequest.getPassword()),"");

        Set<String> stringRoles = signUpRequest.getRole();
        Set<Role> roles = new HashSet<>();
        user.setRoles(roles);

        //userRepository.save(user);
        return ResponseEntity.ok(userRepository.save(user));

    }



}
