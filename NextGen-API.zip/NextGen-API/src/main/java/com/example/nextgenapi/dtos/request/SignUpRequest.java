package com.example.nextgenapi.dtos.request;


import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import jakarta.validation.constraints.*;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data @Builder @ToString
public class SignUpRequest {

    private String firstName;
    private String lastName;

    @NotBlank
    @Size(min = 3, max = 20)
    private String username;

    @NotBlank
    @Size(max = 50)
    @Email
    private String email;
    @NotBlank
    @Size(min = 6, max = 40)
    private String password;

    private Set<String> role;
}