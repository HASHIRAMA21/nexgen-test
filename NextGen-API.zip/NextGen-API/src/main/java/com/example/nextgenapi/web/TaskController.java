package com.example.nextgenapi.web;

import com.example.nextgenapi.entities.Task;
import com.example.nextgenapi.entities.User;
import com.example.nextgenapi.repositories.TaskRepository;
import com.example.nextgenapi.repositories.UserRepository;
import com.example.nextgenapi.services.TaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class TaskController {
    private TaskRepository taskRepository;

    private UserRepository userRepository;

    public TaskController(TaskRepository taskRepository, UserRepository userRepository, TaskService taskService) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.taskService = taskService;
    }

    private TaskService taskService;


    @GetMapping("/tasks")
    public List<Task> getAllTasks(){
        return taskService.getAllTasks();
    }

    @GetMapping("/tasks/{id}")
    public Task getTaskById(@RequestParam UUID taskId){
        return  taskService.getTaskById(taskId);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @DeleteMapping("tasks/{id}")
    public  void deleteTask(@RequestParam UUID taskId){
        taskService.deleteTask(taskId);
    }

    @PreAuthorize("hasRole('ROLE_USER')")
    @PostMapping ("/addTasks")
    public Task addTasks(@RequestBody Task task){
        return taskService.createTask(task);
    }

}

/***
 @PostMapping("/addTask")
 public ResponseEntity<Task> addTask(@RequestBody Task task, @RequestParam UUID  userId){
 Optional<User> user = userRepository.findById(userId);
 try{
 Task task1 = taskRepository.save(
 new Task(UUID.randomUUID(),
 task.getTitle(),
 task.getDescription(),
 task.getStatus(),
 Timestamp.from(Instant.now()),
 Timestamp.from(Instant.now()),userId)
 );
 }catch (Exception e) {
 return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
 }

 }
 ***/
