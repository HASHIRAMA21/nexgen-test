package com.example.nextgenapi.services;

import com.example.nextgenapi.dtos.TaskDto;
import com.example.nextgenapi.entities.Task;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface TaskService {
    //Task createTasks(TaskDto taskDto);
    Task createTask(Task task);
    List<Task> getAllTasks();
    Task getTaskById(UUID taskId);
    void deleteTask(UUID taskId);

   // TaskDto updateTask(TaskDto taskDto);

}
