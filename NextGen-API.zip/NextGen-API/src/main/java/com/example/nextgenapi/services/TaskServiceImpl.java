package com.example.nextgenapi.services;

import com.example.nextgenapi.dtos.TaskDto;
import com.example.nextgenapi.entities.Task;
import com.example.nextgenapi.repositories.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;

    public TaskServiceImpl(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @Override
    public Task createTask(Task task) {
     return taskRepository.save(task);
    }

    @Override
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    @Override
    public Task getTaskById(UUID taskId) {
        Task task;
        task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task Not Found"));
        return task;
    }
    @Override
    public void deleteTask(UUID taskId) {
        taskRepository.deleteById(taskId);
    }

    //@Override
    //public TaskDto updateTask(TaskDto taskDto) {
       // Task task =
     //   return "";
    //}
}
