package com.example.nextgenapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NextGenApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
