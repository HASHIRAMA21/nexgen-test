import 'package:flutter/material.dart';
import 'package:nextgen_app/services/splash.service.dart';

import '../utils/colors.dart';
import '../utils/icons.dart';

class SplashScreenPage extends StatefulWidget {
  const SplashScreenPage({super.key});

  @override
  State<SplashScreenPage> createState() => _SplashScreenPageState();
}

class _SplashScreenPageState extends State<SplashScreenPage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    SplashServices.checkLogin();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: black,
      body: Center(
        child: Container(
            alignment: Alignment.center,
            height: 150,
            width: 150,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100),
                color: primaryColor,
                boxShadow: [
                  BoxShadow(
                      color: Colors.grey.withOpacity(.2),
                      offset: const Offset(1, 1)
                  ),
                  BoxShadow(
                      color: Colors.grey.withOpacity(.2),
                      offset: const Offset(-1, -1)
                  )
                ]
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Image.asset(AppImage.splash),
            )
        ),
      ),
    );
  }

  }
