import 'package:flutter/material.dart';

import '../@core/components/signup/signup_body.dart';
import '../utils/colors.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});
  @override
  State<SignUpPage> createState() => _SignUpState();
}
class _SignUpState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: black,
      body: SafeArea(
        child: SignupBody(),
      ),
    );
  }
}
