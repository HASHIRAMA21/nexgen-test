

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nextgen_app/@core/components/home/progress_container.dart';

import '../../../controllers/home.controller.dart';

class ProgressTask extends StatelessWidget {
  final controller = Get.put(HomeController());

  ProgressTask({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        height: 210,
        width: MediaQuery.sizeOf(context).width,
        child: Obx(
              () => ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: controller.list.length,
            itemBuilder: (context, index) {
              if (controller.list[index].show == 'yes') {
                return GestureDetector(
                    onTap: () {
                      // controller.removeFromList(index);
                    },
                    child: ProgressContainer(index: index)
                );
              } else {
                return const SizedBox();
              }
            },
          ),
        ));
  }
}
