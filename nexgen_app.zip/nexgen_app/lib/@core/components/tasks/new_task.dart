

//import 'dart:ffi'; 
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/colors.dart';
import 'addtask_body.dart';

class NewTask {
  NewTask(Size size) {
    Get.bottomSheet(
        backgroundColor: black,
        isScrollControlled: true,
        TaskBody());
  }
}