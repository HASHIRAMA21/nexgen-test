
import 'package:get/get_navigation/src/routes/get_route.dart';

import '../screens/home.page.dart';
import '../screens/signin.page.dart';
import '../screens/signup.page.dart';
import '../screens/splash.screen.page.dart';

class Routes{
  static const splashScreen='/';
  static const signUpScreen='/signUpScreen';
  static const signInScreen='/signInScreen';
  static const homePage='/homePage';
}

class AppRoutes{
  static List<GetPage> routes(){
    return [
      GetPage(name: Routes.splashScreen, page: ()=> const SplashScreenPage()),
      GetPage(name: Routes.signUpScreen, page: ()=> const SignUpPage()),
      GetPage(name: Routes.signInScreen, page: ()=> const SignInPage()),
      GetPage(name: Routes.homePage, page: ()=> HomePage()),
    ];
  }
}